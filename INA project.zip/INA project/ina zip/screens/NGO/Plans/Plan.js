import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Plan = () => {
  return (
    <View>
      <Text>Plan</Text>
    </View>
  )
}

export default Plan

const styles = StyleSheet.create({})