import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const CHECK = () => {
  return (
    <View>
      <Text>CHECk</Text>
    </View>
  )
}

export default CHECK
const styles = StyleSheet.create({})